<?php

$coche = $_REQUEST["size"];

  

if("agregado"){
    echo "Coche aparcado";

}elseif(""){

    echo "no hay sitio para su coche";
}else{
    echo "ha habido un error";
}



?>